import "./styles.css";
import Navbar from "./components/navbar";
import Home from "./routes/Home";
import { Route, Routes } from "react-router-dom";
import About from "./routes/About";
import Contact from "./routes/Contact";
import Service from "./routes/Service";
import Signin from "./routes/Signin";
import Letsgo from "./routes/Letsgo";

export default function App() {
  return (
    <div className="App">
      <Routes>
        <Route path="/home" element={<Navbar />} />
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/service" element={<Service />} />
        <Route path="/signin" element={<Signin />} />
        <Route path="/letsgo" element={<Letsgo />} />
      </Routes>
    </div>
  );
}
