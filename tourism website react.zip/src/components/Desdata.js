import { Component } from "react";
import "./Destination.css";
class Desdata extends Component {
  render() {
    return (
      <div className="first-des">
        <div className="des-text">
          <h1>{this.props.heading}</h1>
          <p2>{this.props.title}</p2>
        </div>

        <div className="image">
          <img alt="img" src={this.props.img1} />
          <img alt="img" src={this.props.img2} />
        </div>
      </div>
    );
  }
}
export default Desdata;
