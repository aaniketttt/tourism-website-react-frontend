export const menuItems = [
  {
    title: "Home",
    url: "/",
    cName: "navbar-links",
    icon: "fa fa-home"
  },
  {
    title: "About",
    url: "/about",
    cName: "navbar-links",
    icon: "fa fa-address-book"
  },

  {
    title: "Contact",
    url: "/contact",
    cName: "navbar-links",
    icon: "fa fa-address-card"
  },
  {
    title: "Service",
    url: "/service",
    cName: "navbar-links",
    icon: "fa fa-phone"
  },
  {
    title: "Sign In",
    url: "/signin",
    cName: "navbar-links",
    icon: "fa fa-user-circle"
  }
];
