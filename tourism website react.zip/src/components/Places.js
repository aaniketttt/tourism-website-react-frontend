function Places() {
  return <div></div>;
}
export default Places;
