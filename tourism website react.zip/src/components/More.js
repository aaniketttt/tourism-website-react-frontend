import "./more.css";

function More() {
  return (
    <div className="more">
      <h1>EXPLORE MORE</h1>
      <p>Explore more from GOA</p>
    </div>
  );
}
export default More;
