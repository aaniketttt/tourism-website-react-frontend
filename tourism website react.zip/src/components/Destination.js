import "./Destination.css";
import Desdata from "./Desdata";
import beach1 from "../assets/1.jpg";
import beach2 from "../assets/2.jpg";
import waterfall1 from "../assets/3.jpg";
import waterfall2 from "../assets/4.jpg";
import church1 from "../assets/5.jpg";
import church2 from "../assets/6.jpg";
import fort1 from "../assets/7.jpg";
import fort2 from "../assets/8.jpg";

const Destination = () => {
  return (
    <div className="destination">
      <h1>POPULAR DESTINATION</h1>
      <p>The journey of a thousand miles begins with a single step</p>

      <Desdata
        heading="BEACHES"
        title="North Goa is popular for the lively and touristy beaches such as Calangute, Baga, Anjuna, Candolim and Vagator among others. While South Goa houses some of the most secluded and cleanest beaches of Goa such as Palolem, Betalbatim and Betul Beach among others."
        img1={beach1}
        img2={beach2}
      />
      <Desdata
        heading="WATERFALLS"
        title="The strong gushes of water cascading down the mountains and rolling slopes are sights to behold. Situtated in the lush green surroundings of Goa are numerous spectacular waterfalls that will inspire you to pack your bags and go see them for yourself. Photography fanatics will be particularly happy: the waterfalls we’ve listed below offer classic nature shots."
        img1={waterfall1}
        img2={waterfall2}
      />
      <Desdata
        heading="CHURCHES"
        title="Goa not only attracts the visitors for its fun-loving atmosphere, but it is also thronged by visitors who are interested to know its history and love to explore its rich heritage. The popular churches of Goa are must-visit sites for every tourist. Some tourists visit such religious places for spirituality while others just love to explore such sites. Well, whatever the reason is, you must visit top 5 churches in Goa while spending your vacation in this party land."
        img1={church1}
        img2={church2}
      />
      <Desdata
        heading="FORTS"
        title="Ah, Goa! The name seems to have become synonymous with gorgeous beaches, sumptuous seafood, and crazy night-long parties. There’s something about the laid-back sun-and-sea ambiance of Goa that never leaves you bored, even after repeated visits. But, the party capital of India is alive with other treasures as well, if only you care to look around! One such treasure is its mighty forts."
        img1={fort1}
        img2={fort2}
      />
    </div>
  );
};
export default Destination;
