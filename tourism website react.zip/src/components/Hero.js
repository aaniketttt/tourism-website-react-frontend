import "./Hero.css";
import "./aboutus.css";

function Hero(props) {
  return (
    <>
      <div className={props.cName}>
        <img alt="homebg" src={props.bgimg} />
        <div className="home-text">
          <h1>{props.title}</h1>

          <p>{props.subtitle}</p>
          <br></br>

          <a href={props.url} className={props.btn}>
            {props.btnName}
          </a>
        </div>
      </div>

      <div className="abouttl">
        <h2>{props.abouttitle}</h2>
      </div>
    </>
  );
}
export default Hero;
