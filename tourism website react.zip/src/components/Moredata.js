import "./more.css";

function Moredata(props){
  return(
    <div className="m-card">
      <div className="m-image">
        <img src={props.image} alt="image" />
        </div>
        <h3
    </div>
  )
}