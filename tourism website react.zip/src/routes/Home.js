import Destination from "../components/Destination";
import Hero from "../components/Hero";
import Navbar from "../components/navbar";
import More from "../components/More";
function Home() {
  return (
    <>
      <Navbar />
      <Hero
        cName="hero"
        bgimg="https://images.unsplash.com/photo-1507525428034-b723cf961d3e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxleHBsb3JlLWZlZWR8MXx8fGVufDB8fHx8&w=1000&q=80"
        title=" YOUR JOURNEY YOUR STORY"
        subtitle="If Travelling Were Free,You Would Never See Me Again"
        btnName="Lets Go"
        url="/letsgo"
        btn="show"
      />
      <Destination />
      <More />
    </>
  );
}

export default Home;
