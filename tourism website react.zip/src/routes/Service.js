import Navbar from "../components/navbar";
import Hero from "../components/Hero";
function Service() {
  return (
    <>
      <Navbar />
      <Hero
        cName="hero-service"
        bgimg="https://4kwallpapers.com/images/wallpapers/waterfall-forest-aerial-view-5k-3440x1440-5077.jpg"
        title="SERVICE"
        subtitle=""
        btnName=""
        url="/"
        btn=" "
      />
    </>
  );
}

export default Service;
