import Navbar from "../components/navbar";
import Places from "../components/Places";
import "../css/letsgo.css";

function Letsgo() {
  return (
    <>
      <Navbar />
      <Places />
    </>
  );
}
export default Letsgo;
