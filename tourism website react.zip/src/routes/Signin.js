import Navbar from "../components/navbar";
import "../si.css";
function Signin() {
  return (
    <>
      <Navbar />
      <div>
        <img
          alt="signbg"
          src="https://c0.wallpaperflare.com/preview/582/235/745/agonda-india-agonda-beach-sunset.jpg"
        />

        <div className="si">
          <h> sign in</h>
          <form className="form">
            <label>
              Name:
              <input type="text" name="name" />
            </label>
            <input type="submit" value="Submit" />
          </form>
        </div>
      </div>
      <div></div>
    </>
  );
}

export default Signin;
