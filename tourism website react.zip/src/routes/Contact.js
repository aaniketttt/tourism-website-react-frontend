import Hero from "../components/Hero";
import Navbar from "../components/navbar";

function Contact() {
  return (
    <>
      <Navbar />
      <Hero
        cName="hero-contact"
        bgimg="https://www.luxuryvillasstay.com/wp-content/uploads/2019/11/Goa-Nightlife.jpg"
        title="CONTACT US!!"
        subtitle=""
        abouttitle="LET US KNOW"
        btnName=""
        url="/"
        btn=" "
      />
    </>
  );
}

export default Contact;
