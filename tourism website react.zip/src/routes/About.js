import Hero from "../components/Hero";
import Navbar from "../components/navbar";

function About() {
  return (
    <>
      <Navbar />
      <Hero
        cName="hero-abt"
        bgimg="https://images.wallpaperscraft.com/image/single/beach_night_sea_sky_88045_1920x1080.jpg"
        title="ABOUT"
        subtitle=""
        btnName=""
        url="/"
        btn=" "
      />
    </>
  );
}

export default About;
